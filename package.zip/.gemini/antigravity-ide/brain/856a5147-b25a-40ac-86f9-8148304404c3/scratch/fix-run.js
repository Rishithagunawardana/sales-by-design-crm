import fs from 'fs';

const file = 'c:/Users/Adithya Gunawardana/sales by design base 44/server.js';
let content = fs.readFileSync(file, 'utf8');

// Regex to find prepared statement executions that are missing "await".
// Uses negative lookbehind to avoid doubling "await".
// Matches: [identifier].run( or [identifier].get( or [identifier].all(
const regex = /(?<!await\s+)\b([a-zA-Z0-9_]+)\.(run|get|all)\(/g;

let count = 0;
content = content.replace(regex, (match, p1, p2) => {
  count++;
  return `await ${p1}.${p2}(`;
});

fs.writeFileSync(file, content, 'utf8');
console.log(`Prepend "await" to ${count} database statement calls in server.js successfully.`);
