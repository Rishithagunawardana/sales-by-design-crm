import fs from 'fs';
import path from 'path';

const file = 'c:/Users/Adithya Gunawardana/sales by design base 44/server.js';
let content = fs.readFileSync(file, 'utf8');

console.log("Original content size:", content.length);

// 1. Replace DatabaseSync import
content = content.replace(
  "import { DatabaseSync } from 'node:sqlite';",
  "import { createClient } from '@libsql/client';"
);

// 2. Replace database creation (db = new DatabaseSync)
const dbInitTarget = "const db = new DatabaseSync(DB_FILE);";
const dbInitReplacement = `// Initialize libSQL/Turso database client
const client = createClient({
  url: process.env.TURSO_DATABASE_URL || \`file:\${DB_FILE}\`,
  authToken: process.env.TURSO_AUTH_TOKEN
});

const db = {
  exec: async (sql) => {
    return await client.execute(sql);
  },
  prepare: (sql) => {
    return {
      all: async (...args) => {
        const res = await client.execute({ sql, args });
        return res.rows;
      },
      get: async (...args) => {
        const res = await client.execute({ sql, args });
        return res.rows[0];
      },
      run: async (...args) => {
        const res = await client.execute({ sql, args });
        return {
          lastInsertRowid: res.lastInsertRowid !== undefined ? Number(res.lastInsertRowid) : null,
          changes: res.rowsAffected
        };
      }
    };
  }
};`;

content = content.replace(dbInitTarget, dbInitReplacement);

// 3. Replace schema creation (db.exec)
content = content.replace(
  "db.exec(`\r\n  CREATE TABLE IF NOT EXISTS staff (",
  "async function initDatabase() {\r\n  await db.exec(`\r\n  CREATE TABLE IF NOT EXISTS staff ("
);
content = content.replace(
  "db.exec(`\n  CREATE TABLE IF NOT EXISTS staff (",
  "async function initDatabase() {\n  await db.exec(`\n  CREATE TABLE IF NOT EXISTS staff ("
);

// Close of initDatabase function
content = content.replace(
  "    magic_token TEXT UNIQUE,\r\n    is_read INTEGER DEFAULT 0,\r\n    FOREIGN KEY(quote_id) REFERENCES quotes(id),\r\n    FOREIGN KEY(job_id) REFERENCES jobs(id)\r\n  );\r\n`);",
  "    magic_token TEXT UNIQUE,\r\n    is_read INTEGER DEFAULT 0,\r\n    FOREIGN KEY(quote_id) REFERENCES quotes(id),\r\n    FOREIGN KEY(job_id) REFERENCES jobs(id)\r\n  );\r\n`);"
);

// 4. Make logCommunication async
content = content.replace(
  "const logCommunication = (quoteId, jobId, recipient, subject, body, type = 'Email') => {",
  "const logCommunication = async (quoteId, jobId, recipient, subject, body, type = 'Email') => {"
);
content = content.replace(
  "db.prepare(`\r\n    INSERT INTO communications",
  "await db.prepare(`\r\n    INSERT INTO communications"
);
content = content.replace(
  "db.prepare(`\n    INSERT INTO communications",
  "await db.prepare(`\n    INSERT INTO communications"
);

// 5. Make seedDatabase async
content = content.replace(
  "function seedDatabase() {",
  "async function seedDatabase() {"
);

// 6. Make all Express routes async
// Match app.get(..., (req, res) => { or app.post(..., (req, res) => {
// We replace (req, res) => with async (req, res) =>
content = content.replace(
  /app\.(get|post)\((['"][^'"]+['"]),\s*\(req,\s*res\)\s*=>\s*\{/g,
  "app.$1($2, async (req, res) => {"
);

// 7. Add await to database executions
// Matches: db.prepare(...).all(...)
// Matches: db.prepare(...).get(...)
// Matches: db.prepare(...).run(...)
content = content.replace(/db\.prepare\(/g, "await db.prepare(");

// Matches prepared queries run (e.g. insertStaff.run)
const prepStatements = [
  'insertStaff', 'insertAgent', 'insertClient', 'insertStock',
  'insertLedger', 'deductWarehouse', 'addJobLedger'
];
prepStatements.forEach(stmt => {
  const re = new RegExp(`(\\s)(${stmt})\\.run\\(`, 'g');
  content = content.replace(re, '$1await $2.run(');
});

// Since we prefixed all `db.prepare(` with `await db.prepare(`, we now have lines like:
// `const insertStaff = await db.prepare("...");`
// But wait! Prepared statements preparation is SYNCHRONOUS in our mock wrapper:
// `prepare: (sql) => { return { all: ..., get: ..., run: ... } }`
// The `prepare` function itself is NOT a promise! Only the methods `.all`, `.get`, and `.run` return promises!
// So writing `await db.prepare(...)` is actually awaiting a non-promise (an object), which JavaScript fully supports
// (awaiting a non-promise object just returns the object instantly!). So it won't crash or cause issues.
// But wait, it's cleaner to keep db.prepare sync and only await the methods, OR await db.prepare(...) is totally fine too.
// Actually, let's see. If we await db.prepare(...), it's completely fine.
// But wait! In queries like `await db.prepare(...).all(...)`, this evaluates to:
// `(await db.prepare(...)).all(...)`
// But because of operator precedence, `db.prepare(...).all(...)` is evaluated first as:
// `( db.prepare(...).all(...) )`
// So replacing `db.prepare(` with `await db.prepare(` converts:
// `db.prepare(...).all(...)` to `await db.prepare(...).all(...)` which awaits the Promise returned by `.all(...)`!
// Yes! This is EXACTLY correct!
// Because `.` has higher precedence than `await`. So `await db.prepare(...).all(...)` is equivalent to:
// `await ( db.prepare(...).all(...) )`
// Which awaits the `.all(...)` async call!
// This is perfect!

// Let's wrap the start seedDatabase call
content = content.replace(
  "seedDatabase();",
  "" // we will call seedDatabase in initDatabase
);

// Let's modify the end of the schema loader to wrap the initDatabase and listen call:
const startListenText = `// Start server
app.listen(PORT, () => {
  console.log(\`Server listening on port \${PORT}\`);
});`;

const replacementListenText = `// Initialize database and start server
initDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(\`Server listening on port \${PORT}\`);
    });
  })
  .catch(err => {
    console.error("Database initialization failed:", err);
  });`;

content = content.replace(startListenText, replacementListenText);

// Write refactored server.js
fs.writeFileSync(file, content, 'utf8');
console.log("Refactored server.js successfully! New size:", content.length);
